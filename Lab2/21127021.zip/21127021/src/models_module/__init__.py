# Module information:
# - This folder contains the Python source codes used for training, testing Machine Learning model and then use it for makeing predictions.
# File: __init__.py
# Functionality: Making ```models``` become a Python module